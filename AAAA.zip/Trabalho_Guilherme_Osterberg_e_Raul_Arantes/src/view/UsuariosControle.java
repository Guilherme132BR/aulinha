/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import bean.Usuarios;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author u05074221129
 */
public class UsuariosControle extends AbstractTableModel {

    List lista;

    public void setList(List lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return 2;

    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Usuarios usuarios = (Usuarios) lista.get(0);
        if (columnIndex == 0) {
            return "1";
        }
        if (columnIndex == 1) {
            return "raul";
        }
        if (columnIndex == 2) {
            return "rta";
        }
        if (columnIndex == 3) {
            return "05074221129";
        }

        return "";
    }

    @Override
    public String getColumnName(int column) {
        if (column == 0) {
            return "id";
        }
        if (column == 1) {
            return "nome";
        }
        if (column == 2) {
            return "apelido";
        }
        if (column == 3) {
            return "cpf";
        }

        return "";
    }

}
